"""Ambil snapshot data wilayah (provinsi + kab/kota) dari API emsifa.

Hasilnya dibundel sebagai fallback offline:
  fktd/data/provinces.json   -> {"31": "DKI JAKARTA", ...}
  fktd/data/regencies.json   -> {"3171": "KOTA JAKARTA SELATAN", ...}
"""

import json
import urllib.request
from pathlib import Path

BASE = "https://www.emsifa.com/api-wilayah-indonesia/api"
DATA = Path(__file__).resolve().parent.parent / "fktd" / "data"


def _get(url: str):
    req = urllib.request.Request(url, headers={"User-Agent": "fktd/0.1 (+wilayah)"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.load(resp)


def main() -> None:
    provinces = _get(f"{BASE}/provinces.json")
    prov_map = {p["id"]: p["name"].upper() for p in provinces}

    reg_map: dict[str, str] = {}
    for pid in prov_map:
        for r in _get(f"{BASE}/regencies/{pid}.json"):
            reg_map[r["id"]] = r["name"].upper()
        print(f"  provinsi {pid}: total regencies sekarang {len(reg_map)}")

    (DATA / "provinces.json").write_text(
        json.dumps(prov_map, ensure_ascii=False, indent=0), encoding="utf-8"
    )
    (DATA / "regencies.json").write_text(
        json.dumps(reg_map, ensure_ascii=False, indent=0), encoding="utf-8"
    )
    print(f"OK: {len(prov_map)} provinsi, {len(reg_map)} kab/kota.")


if __name__ == "__main__":
    main()
