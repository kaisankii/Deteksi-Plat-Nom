"""Tes unit untuk NIK decoding + rule engine fraud (tanpa butuh gambar)."""

import datetime as dt

from fktd import decode_nik, detect
from fktd.models import KTPData
from fktd.models import Severity

TODAY = dt.date(2026, 6, 4)


def _valid_ktp() -> KTPData:
    # NIK 3172 06 17 08 1995 0001 -> DKI Jakarta, KOTA JAKARTA TIMUR (3172),
    # laki-laki, lahir 17-08-1995. Konsisten dengan field di bawah.
    return KTPData(
        provinsi="DKI JAKARTA",
        kota_kabupaten="KOTA JAKARTA TIMUR",
        nik="3172061708950001",
        nama="BUDI SANTOSO",
        tempat_lahir="JAKARTA",
        tanggal_lahir="17-08-1995",
        jenis_kelamin="LAKI-LAKI",
        golongan_darah="O",
        alamat="JL. MELATI NO 1",
        rt_rw="001/002",
        kel_desa="CIPINANG",
        kecamatan="PULOGADUNG",
        agama="ISLAM",
        status_perkawinan="KAWIN",
        pekerjaan="KARYAWAN SWASTA",
        kewarganegaraan="WNI",
        berlaku_hingga="SEUMUR HIDUP",
        has_foto=True,
        has_tanda_tangan=True,
        confidences={"nik": 92.0, "nama": 88.0, "tanggal_lahir": 90.0},
    )


def test_decode_nik_male():
    info = decode_nik("3175061708950001", reference_year=2026)
    assert info.is_valid_format
    assert info.province_name == "DKI JAKARTA"
    assert info.gender == "LAKI-LAKI"
    assert info.birth_date == dt.date(1995, 8, 17)


def test_decode_nik_female_offset():
    # tanggal 17 + 40 = 57 -> perempuan, lahir tgl 17.
    info = decode_nik("3175065708950001", reference_year=2026)
    assert info.gender == "PEREMPUAN"
    assert info.birth_date == dt.date(1995, 8, 17)


def test_valid_ktp_passes():
    result = detect(_valid_ktp(), today=TODAY)
    assert result.is_passed, result.summary()
    assert result.risk_score == 0


def test_empty_field_fails():
    data = _valid_ktp()
    data.nama = None
    result = detect(data, today=TODAY)
    assert not result.is_passed
    assert any(c.code == "field.nama" for c in result.failed_checks)


def test_nik_dob_mismatch_critical():
    data = _valid_ktp()
    data.tanggal_lahir = "01-01-2000"  # tidak cocok dengan NIK
    result = detect(data, today=TODAY)
    assert not result.is_passed
    codes = {c.code for c in result.failed_checks}
    assert "nik.dob_match" in codes


def test_nik_gender_mismatch():
    data = _valid_ktp()
    data.jenis_kelamin = "PEREMPUAN"  # NIK menunjukkan laki-laki
    result = detect(data, today=TODAY)
    assert not result.is_passed
    assert any(c.code == "nik.gender_match" for c in result.failed_checks)


def test_nik_province_mismatch():
    data = _valid_ktp()
    data.provinsi = "JAWA BARAT"  # NIK 31 = DKI Jakarta
    result = detect(data, today=TODAY)
    assert any(c.code == "nik.province_match" for c in result.failed_checks)


def test_regency_location_mismatch():
    # NIK 3172 = KOTA JAKARTA TIMUR, tapi kartu klaim JAKARTA BARAT -> fraud lokasi.
    data = _valid_ktp()
    data.kota_kabupaten = "JAKARTA BARAT"
    result = detect(data, today=TODAY)
    assert not result.is_passed
    assert any(c.code == "nik.regency_match" for c in result.failed_checks)


def test_berlaku_hingga_must_be_seumur_hidup():
    data = _valid_ktp()
    data.berlaku_hingga = "22-02-2017"  # e-KTP harus SEUMUR HIDUP
    result = detect(data, today=TODAY)
    assert not result.is_passed
    assert any(c.code == "date.berlaku" for c in result.failed_checks)


def test_short_nik_fails():
    data = _valid_ktp()
    data.nik = "12345"
    result = detect(data, today=TODAY)
    assert not result.is_passed
    assert any(
        c.code == "nik.format" and c.severity is Severity.CRITICAL
        for c in result.failed_checks
    )


def test_invalid_agama_rejected():
    data = _valid_ktp()
    data.agama = "PASTAFARIAN"  # bukan 1 dari 6 agama resmi
    result = detect(data, today=TODAY)
    assert not result.is_passed
    assert any(c.code == "enum.agama" for c in result.failed_checks)


def test_six_recognized_religions_pass():
    for ag in ("ISLAM", "KRISTEN", "KRISTEN PROTESTAN", "KATOLIK", "HINDU",
               "BUDHA", "KONGHUCU"):
        data = _valid_ktp()
        data.agama = ag
        result = detect(data, today=TODAY)
        assert result.is_passed, f"{ag}: {result.summary()}"


def test_kewarganegaraan_must_be_wni_or_wna():
    data = _valid_ktp()
    data.kewarganegaraan = "CHINA"
    result = detect(data, today=TODAY)
    assert not result.is_passed
    assert any(c.code == "enum.kewarganegaraan" for c in result.failed_checks)


def test_values_must_be_uppercase():
    data = _valid_ktp()
    data.nama = "Budi Santoso"  # ada huruf kecil
    result = detect(data, today=TODAY)
    assert any(c.code == "format.uppercase.nama" for c in result.failed_checks)


def test_nama_with_digit_rejected():
    data = _valid_ktp()
    data.nama = "BUDI 123"
    result = detect(data, today=TODAY)
    assert not result.is_passed
    assert any(c.code == "format.nama" for c in result.failed_checks)


def test_missing_foto_critical():
    data = _valid_ktp()
    data.has_foto = False
    result = detect(data, today=TODAY)
    assert not result.is_passed
    assert any(c.code == "vision.foto" for c in result.failed_checks)
