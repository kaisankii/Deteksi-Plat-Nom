"""Jalankan pipeline FKTD penuh atas seluruh gambar di image-test-sample/."""

import glob
import os

from fktd import FKTD

SAMPLES = sorted(glob.glob(os.path.join("image-test-sample", "*")))


def main() -> None:
    detector = FKTD(engine="easyocr")  # model di-download sekali di sini
    for path in SAMPLES:
        print("=" * 70)
        print(f"FILE: {path}")
        print("-" * 70)
        result = detector.process(path)
        data = result.data

        print("[FIELD HASIL OCR]")
        for k, v in data.model_dump(exclude={"confidences"}).items():
            print(f"  {k:20s}: {v}")

        print("\n[FRAUD]")
        print(f"  is_passed  : {result.is_passed}")
        print(f"  risk_score : {result.risk_score}")
        fails = result.failed_checks
        if fails:
            print("  gagal:")
            for c in fails:
                print(f"    - ({c.severity.value:8s}) {c.code}: {c.message}")
        else:
            print("  semua check lolos")
        print()


if __name__ == "__main__":
    main()
