"""Orkestrator utama: upload -> OCR -> ekstraksi -> deteksi fraud -> hasil."""

from __future__ import annotations

import datetime as _dt
from typing import Optional, Union

from . import vision
from .extractor import extract
from .fraud import detect
from .models import FraudResult, KTPData
from .ocr import DEFAULT_ENGINE, ImageInput, OCREngine, get_engine, load_image
from .wilayah import WilayahResolver


class FKTD:
    """Fraud KYC KTP Detector.

    Contoh::

        from fktd import FKTD

        detector = FKTD(engine="easyocr")   # atau "paddle"
        result = detector.process("ktp.jpg")
        print(result.is_passed, result.risk_score)
        print(result.summary())
    """

    def __init__(
        self,
        *,
        engine: Union[str, OCREngine] = DEFAULT_ENGINE,
        lang: str | None = None,
        risk_threshold: int = 25,
        min_confidence: float = 60.0,
        detect_vision: bool = True,
        wilayah_provider: str = "auto",
        **engine_kwargs,
    ) -> None:
        if isinstance(engine, OCREngine):
            self.engine = engine
        else:
            self.engine = get_engine(engine, lang=lang, **engine_kwargs)
        self.risk_threshold = risk_threshold
        self.min_confidence = min_confidence
        self.detect_vision = detect_vision
        # "auto": snapshot lokal dulu, API untuk kode yang belum ada di snapshot.
        self.resolver = WilayahResolver(provider=wilayah_provider)

    def extract_fields(self, image: ImageInput) -> KTPData:
        """Hanya OCR + ekstraksi field (tanpa deteksi fraud)."""
        raw = load_image(image)
        ocr = self.engine.run(raw)
        data = extract(ocr)
        if self.detect_vision:
            data.has_foto = vision.detect_foto(raw)
            data.has_tanda_tangan = vision.detect_tanda_tangan(raw)
        return data

    def process(
        self, image: ImageInput, *, today: Optional[_dt.date] = None
    ) -> FraudResult:
        """Pipeline penuh: kembalikan ``FraudResult``."""
        data = self.extract_fields(image)
        return detect(
            data,
            risk_threshold=self.risk_threshold,
            min_confidence=self.min_confidence,
            today=today,
            resolver=self.resolver,
        )
