"""Field extraction: ubah teks OCR mentah menjadi ``KTPData`` terstruktur."""

from __future__ import annotations

import re
from typing import Optional

from .models import KTPData
from .ocr import OCRResult

# Label baris KTP -> nama field di model. Disusun urut kemunculan di kartu.
_LABELS: list[tuple[str, str]] = [
    (r"nik", "nik"),
    (r"nama", "nama"),
    (r"tempat\s*/?\s*tgl\s*lahir", "_tempat_tgl_lahir"),
    (r"jenis\s*kelamin", "jenis_kelamin"),
    (r"gol\.?\s*darah", "golongan_darah"),
    (r"alamat", "alamat"),
    (r"rt\s*/?\s*rw", "rt_rw"),
    (r"kel\s*/?\s*desa", "kel_desa"),
    (r"kecamatan", "kecamatan"),
    (r"agama", "agama"),
    (r"status\s*perkawinan", "status_perkawinan"),
    (r"pekerjaan", "pekerjaan"),
    (r"kewarganegaraan", "kewarganegaraan"),
    (r"berlaku\s*hingga", "berlaku_hingga"),
]

_NIK_RE = re.compile(r"\b(\d[\d\s.]{14,20}\d)\b")
_DATE_RE = re.compile(r"(\d{1,2})\s*[-/]\s*(\d{1,2})\s*[-/]\s*(\d{4})")
_RTRW_RE = re.compile(r"(\d{1,3})\s*/\s*(\d{1,3})")


def _strip_label(line: str, label_pattern: str) -> str:
    """Hapus label + pemisah (':') dari awal baris, sisakan nilainya."""
    cleaned = re.sub(rf"^.*?{label_pattern}\s*:?\s*", "", line, flags=re.IGNORECASE)
    return cleaned.strip(" :\t")


def extract(ocr: OCRResult) -> KTPData:
    data = KTPData()
    lines = [ln for ln in ocr.text.splitlines() if ln.strip()]

    # Provinsi & Kota/Kabupaten biasanya 2 baris pertama (huruf kapital, tanpa label).
    _extract_header(lines, data)

    for line in lines:
        low = line.lower()
        for pattern, field in _LABELS:
            if re.search(pattern, low):
                value = _strip_label(line, pattern)
                _assign(data, field, value)
                break

    _extract_issuance(lines, data)
    _attach_confidences(ocr, data)
    return data


def _extract_header(lines: list[str], data: KTPData) -> None:
    for line in lines[:3]:
        low = line.lower()
        if "provinsi" in low:
            data.provinsi = re.sub(r"(?i)provinsi", "", line).strip()
        elif data.provinsi and not data.kota_kabupaten and re.search(r"[A-Z]{3,}", line):
            # baris setelah provinsi yang full-caps -> kota/kabupaten.
            if not any(re.search(p, low) for p, _ in _LABELS):
                data.kota_kabupaten = line.strip()


def _assign(data: KTPData, field: str, value: str) -> None:
    if field == "_tempat_tgl_lahir":
        tempat, tanggal = _split_tempat_tgl(value)
        data.tempat_lahir = tempat or None
        data.tanggal_lahir = tanggal
        return
    if field == "nik":
        m = _NIK_RE.search(value)
        data.nik = re.sub(r"\D", "", m.group(1)) if m else (value or None)
        return
    if field == "rt_rw":
        m = _RTRW_RE.search(value)
        data.rt_rw = f"{m.group(1)}/{m.group(2)}" if m else (value or None)
        return
    setattr(data, field, value or None)


def _split_tempat_tgl(value: str) -> tuple[str, Optional[str]]:
    m = _DATE_RE.search(value)
    if not m:
        return value.strip().rstrip(","), None
    tanggal = f"{int(m.group(1)):02d}-{int(m.group(2)):02d}-{m.group(3)}"
    tempat = value[: m.start()].strip().rstrip(",").strip()
    return tempat, tanggal


def _extract_issuance(lines: list[str], data: KTPData) -> None:
    """Tempat & tanggal dikeluarkan: blok pojok kanan bawah.

    Heuristik: baris terakhir yang memuat tanggal dd-mm-yyyy dan TIDAK termasuk
    tanggal lahir dianggap tanggal dikeluarkan; teks sebelum tanggal = tempat.
    """
    for line in reversed(lines):
        m = _DATE_RE.search(line)
        if not m:
            continue
        tgl = f"{int(m.group(1)):02d}-{int(m.group(2)):02d}-{m.group(3)}"
        if tgl == data.tanggal_lahir:
            continue
        data.tanggal_dikeluarkan = tgl
        tempat = line[: m.start()].strip(" :,")
        if tempat and re.search(r"[A-Za-z]", tempat):
            data.tempat_dikeluarkan = tempat
        break


def _attach_confidences(ocr: OCRResult, data: KTPData) -> None:
    """Kaitkan confidence OCR ke tiap field berdasarkan kemunculan nilainya."""
    for field, value in data.model_dump().items():
        if not isinstance(value, str) or not value.strip():
            continue
        tokens = [t for t in re.split(r"\W+", value) if len(t) >= 2]
        if not tokens:
            continue
        confs = [w.conf for w in ocr.words for t in tokens if t.lower() in w.text.lower()]
        if confs:
            data.confidences[field] = round(sum(confs) / len(confs), 1)
