"""Rule engine deteksi fraud KTP.

Strategi: setiap aturan menghasilkan ``FraudCheck``. Kegagalan menambah bobot
ke ``risk_score`` (0-100). Kelulusan (``is_passed``) butuh:

* semua field wajib terisi,
* tidak ada kegagalan ``CRITICAL``,
* ``risk_score`` di bawah ``risk_threshold``.
"""

from __future__ import annotations

import datetime as _dt
import re
from typing import Optional

from dateutil import parser as _dtparser

from .models import FraudCheck, FraudResult, KTPData, Severity
from .nik import NIKInfo, decode_nik, normalize_nik
from .wilayah import WilayahResolver

# ---- master nilai valid (enum) -------------------------------------------
JENIS_KELAMIN = {"LAKI-LAKI", "PEREMPUAN"}
# Hanya 6 agama yang diakui negara (Kristen Protestan == Kristen).
AGAMA = {"ISLAM", "KRISTEN", "KRISTEN PROTESTAN", "KATOLIK", "HINDU", "BUDHA", "KONGHUCU"}
STATUS_KAWIN = {"BELUM KAWIN", "KAWIN", "CERAI HIDUP", "CERAI MATI"}
KEWARGANEGARAAN = {"WNI", "WNA"}
GOL_DARAH = {"A", "B", "AB", "O", "-"}

# Field wajib ada untuk lolos pengecekan kelengkapan.
REQUIRED_FIELDS = [
    "provinsi", "kota_kabupaten", "nik", "nama", "tempat_lahir", "tanggal_lahir",
    "jenis_kelamin", "alamat", "rt_rw", "kel_desa", "kecamatan", "agama",
    "status_perkawinan", "pekerjaan", "kewarganegaraan", "berlaku_hingga",
]

# Field nilai (setelah ':') yang harus HURUF KAPITAL semua di KTP asli.
UPPERCASE_FIELDS = [
    "provinsi", "kota_kabupaten", "nama", "tempat_lahir", "jenis_kelamin",
    "golongan_darah", "alamat", "kel_desa", "kecamatan", "agama",
    "status_perkawinan", "pekerjaan", "kewarganegaraan", "berlaku_hingga",
]

# Field yang confidence OCR-nya kritikal untuk anti-fraud.
CONF_CRITICAL_FIELDS = ["nik", "nama", "tanggal_lahir"]


def _norm(text: Optional[str]) -> str:
    return (text or "").strip().upper()


def _parse_date(text: Optional[str]) -> Optional[_dt.date]:
    if not text:
        return None
    m = re.search(r"(\d{1,2})[-/](\d{1,2})[-/](\d{4})", text)
    if m:
        try:
            return _dt.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
        except ValueError:
            return None
    try:
        return _dtparser.parse(text, dayfirst=True).date()
    except (ValueError, OverflowError):
        return None


def detect(
    data: KTPData,
    *,
    risk_threshold: int = 25,
    min_confidence: float = 60.0,
    today: Optional[_dt.date] = None,
    resolver: Optional[WilayahResolver] = None,
) -> FraudResult:
    today = today or _dt.date.today()
    resolver = resolver or WilayahResolver(provider="local")
    info = decode_nik(normalize_nik(data.nik), reference_year=today.year)
    checks: list[FraudCheck] = []

    checks.extend(_check_completeness(data))
    checks.extend(_check_nik(data, info))
    checks.extend(_check_location(data, info, resolver))
    checks.extend(_check_enums(data))
    checks.extend(_check_text_format(data))
    checks.extend(_check_dates(data, today))
    checks.extend(_check_rtrw(data))
    checks.extend(_check_vision(data))
    checks.extend(_check_confidence(data, min_confidence))

    risk_score = min(100, sum(c.weight for c in checks if not c.passed))
    has_critical = any(
        (not c.passed) and c.severity is Severity.CRITICAL for c in checks
    )
    is_passed = (not has_critical) and risk_score < risk_threshold
    return FraudResult(
        is_passed=is_passed, risk_score=risk_score, checks=checks, data=data
    )


# ---------------------------------------------------------------------------
def _ok(code: str, msg: str) -> FraudCheck:
    return FraudCheck(code=code, passed=True, severity=Severity.INFO, message=msg)


def _fail(code: str, msg: str, sev: Severity, weight: int) -> FraudCheck:
    return FraudCheck(code=code, passed=False, severity=sev, message=msg, weight=weight)


def _check_completeness(data: KTPData) -> list[FraudCheck]:
    checks = []
    for field in REQUIRED_FIELDS:
        value = getattr(data, field, None)
        if value and str(value).strip():
            checks.append(_ok(f"field.{field}", f"{field} terisi"))
        else:
            checks.append(
                _fail(
                    f"field.{field}",
                    f"Field wajib '{field}' kosong",
                    Severity.CRITICAL,
                    weight=15,
                )
            )
    return checks


def _check_nik(data: KTPData, info: NIKInfo) -> list[FraudCheck]:
    checks: list[FraudCheck] = []

    if not info.is_valid_format:
        checks.append(
            _fail("nik.format", f"NIK harus 16 digit (dapat {len(info.nik)})",
                  Severity.CRITICAL, 30)
        )
        return checks
    checks.append(_ok("nik.format", "NIK 16 digit"))

    # Tanggal lahir di NIK vs field.
    field_dob = _parse_date(data.tanggal_lahir)
    if info.birth_date and field_dob:
        if info.birth_date == field_dob:
            checks.append(_ok("nik.dob_match", "Tgl lahir NIK cocok dengan field"))
        else:
            checks.append(
                _fail("nik.dob_match",
                      f"Tgl lahir NIK ({info.birth_date}) != field ({field_dob})",
                      Severity.CRITICAL, 30)
            )
    elif info.birth_date is None:
        checks.append(
            _fail("nik.dob_valid", "Digit tgl lahir di NIK tidak valid",
                  Severity.CRITICAL, 20)
        )

    # Gender di NIK vs field.
    if info.gender and data.jenis_kelamin:
        if info.gender in _norm(data.jenis_kelamin):
            checks.append(_ok("nik.gender_match", "Gender NIK cocok dengan field"))
        else:
            checks.append(
                _fail("nik.gender_match",
                      f"Gender NIK ({info.gender}) != field "
                      f"({_norm(data.jenis_kelamin)})",
                      Severity.CRITICAL, 25)
            )
    return checks


def _region_core(name: Optional[str]) -> str:
    """Normalkan nama wilayah untuk dibandingkan (buang KOTA/KABUPATEN/ADM)."""
    text = _norm(name)
    for token in ("KOTA ADMINISTRASI", "KABUPATEN ADMINISTRASI", "KOTA ADM.",
                  "KABUPATEN", "KOTA", "KAB.", "KAB", "ADMINISTRASI", "ADM."):
        text = text.replace(token, " ")
    return re.sub(r"[^A-Z]+", " ", text).strip()


def _check_location(
    data: KTPData, info: NIKInfo, resolver: WilayahResolver
) -> list[FraudCheck]:
    """Validasi lokasi NIK terhadap field via data wilayah (API + snapshot).

    * kode provinsi (2 digit) -> harus cocok field Provinsi
    * kode kab/kota (4 digit) -> harus cocok field Kota/Kabupaten
    """
    if not info.is_valid_format:
        return []
    checks: list[FraudCheck] = []

    # -- provinsi (2 digit) --
    prov_name = resolver.province_name(info.province_code)
    if prov_name is None:
        checks.append(
            _fail("nik.province_code",
                  f"Kode provinsi '{info.province_code}' di NIK tidak dikenal",
                  Severity.CRITICAL, 25)
        )
    else:
        checks.append(_ok("nik.province_code", f"Kode provinsi {info.province_code} valid"))
        if data.provinsi and _region_core(prov_name) not in _region_core(data.provinsi):
            checks.append(
                _fail("nik.province_match",
                      f"Provinsi di NIK ({prov_name}) != field ({_norm(data.provinsi)})",
                      Severity.CRITICAL, 25)
            )
        elif data.provinsi:
            checks.append(_ok("nik.province_match", "Provinsi NIK cocok dengan field"))

    # -- kabupaten/kota (4 digit) --
    reg_code = f"{info.province_code}{info.regency_code}"
    reg_name = resolver.regency_name(reg_code)
    if reg_name is None:
        checks.append(
            _fail("nik.regency_code",
                  f"Kode kab/kota '{reg_code}' di NIK tidak dikenal",
                  Severity.CRITICAL, 25)
        )
    else:
        checks.append(_ok("nik.regency_code", f"Kode kab/kota {reg_code} = {reg_name}"))
        field_kota = data.kota_kabupaten
        if field_kota:
            nik_core = _region_core(reg_name)
            field_core = _region_core(field_kota)
            if nik_core and (nik_core in field_core or field_core in nik_core):
                checks.append(_ok("nik.regency_match", "Kota/Kab NIK cocok dengan field"))
            else:
                checks.append(
                    _fail("nik.regency_match",
                          f"Kota/Kab di NIK ({reg_name}) != field ({_norm(field_kota)})",
                          Severity.CRITICAL, 25)
                )
    return checks


def _check_enums(data: KTPData) -> list[FraudCheck]:
    checks = []
    checks.append(_enum_check("jenis_kelamin", data.jenis_kelamin, JENIS_KELAMIN,
                              Severity.CRITICAL, 20))
    checks.append(_enum_check("agama", data.agama, AGAMA, Severity.CRITICAL, 20))
    checks.append(_enum_check("status_perkawinan", data.status_perkawinan, STATUS_KAWIN,
                              Severity.WARNING, 10))
    checks.append(_enum_check("kewarganegaraan", data.kewarganegaraan, KEWARGANEGARAAN,
                              Severity.CRITICAL, 20))
    if data.golongan_darah:
        gd = _norm(data.golongan_darah).replace(".", "")
        if gd in GOL_DARAH:
            checks.append(_ok("enum.golongan_darah", "Gol. darah valid"))
        else:
            checks.append(
                _fail("enum.golongan_darah", f"Gol. darah '{gd}' tidak valid",
                      Severity.WARNING, 5)
            )
    return [c for c in checks if c is not None]


def _enum_check(
    field: str, value: Optional[str], allowed: set[str],
    severity: Severity = Severity.WARNING, weight: int = 10,
) -> Optional[FraudCheck]:
    """Exact-match terhadap daftar nilai resmi (bukan substring)."""
    if not value:
        return None  # kelengkapan ditangani terpisah
    if _norm(value) in allowed:
        return _ok(f"enum.{field}", f"{field} valid")
    return _fail(f"enum.{field}",
                 f"Nilai '{value}' tidak termasuk nilai resmi {field}: {sorted(allowed)}",
                 severity, weight)


def _check_text_format(data: KTPData) -> list[FraudCheck]:
    """Aturan format teks KTP asli.

    * semua nilai field (setelah ':') harus HURUF KAPITAL,
    * Nama tidak boleh mengandung angka.
    """
    checks: list[FraudCheck] = []
    for field in UPPERCASE_FIELDS:
        value = getattr(data, field, None)
        if not value:
            continue
        if any(ch.islower() for ch in value):
            checks.append(
                _fail(f"format.uppercase.{field}",
                      f"Nilai '{field}' harus huruf kapital semua: '{value}'",
                      Severity.WARNING, 10)
            )
        else:
            checks.append(_ok(f"format.uppercase.{field}", f"{field} kapital"))

    if data.nama and re.search(r"\d", data.nama):
        checks.append(
            _fail("format.nama", f"Nama mengandung angka: '{data.nama}'",
                  Severity.CRITICAL, 20)
        )
    return checks


def _check_dates(data: KTPData, today: _dt.date) -> list[FraudCheck]:
    checks = []
    dob = _parse_date(data.tanggal_lahir)
    if data.tanggal_lahir and dob is None:
        checks.append(_fail("date.lahir_format", "Format tgl lahir tidak valid",
                            Severity.WARNING, 10))
    elif dob:
        if dob > today:
            checks.append(_fail("date.lahir_future", "Tgl lahir di masa depan",
                                Severity.CRITICAL, 25))
        else:
            age = (today - dob).days // 365
            if age > 120:
                checks.append(_fail("date.lahir_age", f"Umur tidak masuk akal ({age} th)",
                                    Severity.WARNING, 10))
            else:
                checks.append(_ok("date.lahir", "Tgl lahir wajar"))

    # Berlaku hingga: sejak 2016 e-KTP berlaku SEUMUR HIDUP. Tanggal kedaluwarsa
    # = kartu lama/tidak valid -> ditolak.
    bh = _norm(data.berlaku_hingga)
    if bh:
        if "SEUMUR HIDUP" in bh:
            checks.append(_ok("date.berlaku", "Berlaku seumur hidup"))
        else:
            checks.append(
                _fail("date.berlaku",
                      f"Berlaku hingga harus 'SEUMUR HIDUP' (dapat '{data.berlaku_hingga}')",
                      Severity.CRITICAL, 25)
            )
    return checks


def _check_rtrw(data: KTPData) -> list[FraudCheck]:
    if not data.rt_rw:
        return []
    if re.fullmatch(r"\d{1,3}/\d{1,3}", data.rt_rw.strip()):
        return [_ok("format.rt_rw", "RT/RW valid")]
    return [_fail("format.rt_rw", f"Format RT/RW '{data.rt_rw}' tidak valid",
                  Severity.WARNING, 5)]


def _check_vision(data: KTPData) -> list[FraudCheck]:
    checks = []
    if data.has_foto:
        checks.append(_ok("vision.foto", "Foto terdeteksi"))
    else:
        checks.append(_fail("vision.foto", "Foto tidak terdeteksi",
                            Severity.CRITICAL, 20))
    if data.has_tanda_tangan:
        checks.append(_ok("vision.ttd", "Tanda tangan terdeteksi"))
    else:
        checks.append(_fail("vision.ttd", "Tanda tangan tidak terdeteksi",
                            Severity.WARNING, 10))
    return checks


def _check_confidence(data: KTPData, min_confidence: float) -> list[FraudCheck]:
    checks = []
    for field in CONF_CRITICAL_FIELDS:
        conf = data.confidence_of(field)
        if conf == 0.0:
            continue  # field tidak terbaca; ditangani oleh kelengkapan
        if conf < min_confidence:
            checks.append(
                _fail(f"ocr.confidence.{field}",
                      f"Confidence OCR '{field}' rendah ({conf} < {min_confidence})",
                      Severity.WARNING, 8)
            )
        else:
            checks.append(_ok(f"ocr.confidence.{field}", f"Confidence '{field}' OK"))
    return checks
