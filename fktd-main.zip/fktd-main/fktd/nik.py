"""NIK (Nomor Induk Kependudukan) decoding and validation.

A valid NIK is exactly 16 digits and is *structured*::

    PP RR DD  DDMMYY  SSSS
    │  │  │   │       └── 13-16: nomor urut harian
    │  │  │   └────────── 7-12 : tanggal lahir (DD+40 jika perempuan)
    │  │  └────────────── 5-6  : kode kecamatan
    │  └───────────────── 3-4  : kode kabupaten/kota
    └──────────────────── 1-2  : kode provinsi

Karena tanggal lahir dan jenis kelamin ter-*encode* di dalam NIK, kita bisa
melakukan cross-check ketat terhadap field hasil OCR.
"""

from __future__ import annotations

import datetime as _dt
import json
from dataclasses import dataclass
from importlib import resources
from typing import Optional

# Perempuan: tanggal lahir + 40 pada digit ke 7-8.
_FEMALE_OFFSET = 40


def _load_provinces() -> dict[str, str]:
    with resources.files("fktd.data").joinpath("wilayah.json").open(
        "r", encoding="utf-8"
    ) as fh:
        return json.load(fh)


PROVINCE_CODES: dict[str, str] = _load_provinces()


@dataclass(frozen=True)
class NIKInfo:
    """Hasil decode sebuah NIK."""

    nik: str
    is_valid_format: bool
    province_code: Optional[str] = None
    province_name: Optional[str] = None
    regency_code: Optional[str] = None
    district_code: Optional[str] = None
    birth_date: Optional[_dt.date] = None
    gender: Optional[str] = None  # "LAKI-LAKI" / "PEREMPUAN"
    sequence: Optional[str] = None


def normalize_nik(raw: Optional[str]) -> str:
    """Buang semua karakter non-digit (spasi, titik, dsb) dari NIK."""
    if not raw:
        return ""
    return "".join(ch for ch in str(raw) if ch.isdigit())


def decode_nik(raw: Optional[str], *, reference_year: Optional[int] = None) -> NIKInfo:
    """Decode NIK menjadi komponen-komponennya.

    ``reference_year`` dipakai untuk menebak abad tanggal lahir (YY 2 digit).
    Default-nya tahun berjalan.
    """
    nik = normalize_nik(raw)
    if len(nik) != 16:
        return NIKInfo(nik=nik, is_valid_format=False)

    province_code = nik[0:2]
    regency_code = nik[2:4]
    district_code = nik[4:6]
    dd = int(nik[6:8])
    mm = int(nik[8:10])
    yy = int(nik[10:12])
    sequence = nik[12:16]

    if dd > _FEMALE_OFFSET:
        gender = "PEREMPUAN"
        day = dd - _FEMALE_OFFSET
    else:
        gender = "LAKI-LAKI"
        day = dd

    birth_date = _resolve_birth_date(day, mm, yy, reference_year)

    return NIKInfo(
        nik=nik,
        is_valid_format=True,
        province_code=province_code,
        province_name=PROVINCE_CODES.get(province_code),
        regency_code=regency_code,
        district_code=district_code,
        birth_date=birth_date,
        gender=gender,
        sequence=sequence,
    )


def _resolve_birth_date(
    day: int, month: int, yy: int, reference_year: Optional[int]
) -> Optional[_dt.date]:
    ref = reference_year or _dt.date.today().year
    ref_yy = ref % 100
    # Jika YY <= dua digit tahun sekarang -> abad ini, selain itu abad lalu.
    century = (ref // 100) * 100
    year = century + yy if yy <= ref_yy else century - 100 + yy
    try:
        return _dt.date(year, month, day)
    except ValueError:
        return None
