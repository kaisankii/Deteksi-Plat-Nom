"""Layer OCR multi-engine yang bisa di-swap.

Engine tersedia: ``easyocr`` (default, mulus di Mac) dan ``paddle`` (akurasi
tinggi, ideal di server Linux). Engine bersifat *optional dependency*::

    pip install 'fktd[easyocr]'
    pip install 'fktd[paddle]'
    pip install 'fktd[all]'
"""

from __future__ import annotations

from .base import (
    ImageInput,
    OCREngine,
    OCREngineError,
    OCRResult,
    OCRWord,
    load_image,
    reconstruct_lines,
)

# nama -> "module:class" (lazy import agar dependency tetap opsional).
_ENGINES: dict[str, tuple[str, str]] = {
    "easyocr": ("fktd.ocr.easyocr_engine", "EasyOCREngine"),
    "paddle": ("fktd.ocr.paddle_engine", "PaddleOCREngine"),
}

DEFAULT_ENGINE = "easyocr"


def available_engines() -> list[str]:
    return list(_ENGINES)


def get_engine(name: str = DEFAULT_ENGINE, **kwargs) -> OCREngine:
    """Buat instance backend OCR berdasarkan nama.

    ``kwargs`` diteruskan ke konstruktor engine (mis. ``lang``, ``gpu``).
    """
    key = name.lower()
    if key not in _ENGINES:
        raise OCREngineError(
            f"Engine '{name}' tidak dikenal. Pilihan: {', '.join(_ENGINES)}"
        )
    import importlib

    module_path, class_name = _ENGINES[key]
    module = importlib.import_module(module_path)
    engine_cls = getattr(module, class_name)
    return engine_cls(**kwargs)


__all__ = [
    "ImageInput",
    "OCRResult",
    "OCRWord",
    "OCREngine",
    "OCREngineError",
    "load_image",
    "reconstruct_lines",
    "get_engine",
    "available_engines",
    "DEFAULT_ENGINE",
]
