"""Backend OCR: PaddleOCR. Akurasi tinggi; ideal di server Linux."""

from __future__ import annotations

import numpy as np

from .base import OCREngine, OCRWord, _missing_dependency


class PaddleOCREngine(OCREngine):
    name = "paddle"

    def __init__(self, *, lang: str | None = None, use_angle_cls: bool = True) -> None:
        # KTP huruf Latin -> model 'latin' menangani bahasa Indonesia.
        resolved = {"ind": "latin", "id": "latin"}.get(lang or "latin", lang or "latin")
        try:
            from paddleocr import PaddleOCR
        except ImportError as exc:
            raise _missing_dependency("paddle", "paddleocr", "paddle") from exc
        self._ocr = PaddleOCR(use_angle_cls=use_angle_cls, lang=resolved, show_log=False)

    def _recognize(self, img_bgr: np.ndarray) -> list[OCRWord]:
        result = self._ocr.ocr(img_bgr, cls=True)
        words: list[OCRWord] = []
        # Struktur: [[ [box, (text, conf)], ... ]]  (per halaman).
        for page in result or []:
            for line in page or []:
                box, (text, conf) = line[0], line[1]
                if not str(text).strip():
                    continue
                xs = [int(p[0]) for p in box]
                ys = [int(p[1]) for p in box]
                words.append(
                    OCRWord(
                        text=str(text),
                        conf=float(conf) * 100.0,
                        left=min(xs),
                        top=min(ys),
                    )
                )
        return words
