"""Backend OCR: EasyOCR (berbasis PyTorch). Mulus di Apple Silicon."""

from __future__ import annotations

import numpy as np

from .base import OCREngine, OCRWord, _missing_dependency


class EasyOCREngine(OCREngine):
    name = "easyocr"

    def __init__(self, *, lang: str | list[str] | None = None, gpu: bool = False) -> None:
        if lang is None:
            langs = ["id", "en"]
        elif isinstance(lang, str):
            # terima 'ind'/'id' -> normalkan ke kode EasyOCR.
            langs = [{"ind": "id"}.get(lang, lang), "en"]
        else:
            langs = lang
        try:
            import easyocr
        except ImportError as exc:
            raise _missing_dependency("easyocr", "easyocr", "easyocr") from exc
        # Reader berat untuk diinisialisasi -> dibuat sekali di sini.
        self._reader = easyocr.Reader(langs, gpu=gpu)

    def _recognize(self, img_bgr: np.ndarray) -> list[OCRWord]:
        # EasyOCR menerima array RGB/BGR; detail=1 -> (box, text, conf).
        results = self._reader.readtext(img_bgr, detail=1, paragraph=False)
        words: list[OCRWord] = []
        for box, text, conf in results:
            if not str(text).strip():
                continue
            xs = [int(p[0]) for p in box]
            ys = [int(p[1]) for p in box]
            words.append(
                OCRWord(
                    text=str(text),
                    conf=float(conf) * 100.0,  # 0-1 -> 0-100
                    left=min(xs),
                    top=min(ys),
                )
            )
        return words
