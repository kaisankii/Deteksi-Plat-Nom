"""Tipe & kontrak dasar untuk semua backend OCR.

Semua engine (Tesseract/EasyOCR/PaddleOCR) menghasilkan struktur yang sama:
``OCRResult`` berisi teks tersusun per baris + ``OCRWord`` dengan confidence
ternormalisasi ke skala **0-100** dan posisi piksel.
"""

from __future__ import annotations

import abc
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Union

import cv2
import numpy as np

ImageInput = Union[str, Path, np.ndarray]


@dataclass
class OCRWord:
    text: str
    conf: float  # 0-100
    left: int
    top: int


@dataclass
class OCRResult:
    text: str
    words: list[OCRWord]
    engine: str
    image: Optional[np.ndarray] = field(default=None, repr=False)

    def mean_confidence(self) -> float:
        vals = [w.conf for w in self.words if w.text.strip()]
        return float(sum(vals) / len(vals)) if vals else 0.0


def load_image(image: ImageInput) -> np.ndarray:
    """Muat gambar menjadi array BGR (OpenCV)."""
    if isinstance(image, np.ndarray):
        return image
    path = str(image)
    img = cv2.imread(path)
    if img is None:
        raise FileNotFoundError(f"Tidak bisa membaca gambar: {path}")
    return img


def reconstruct_lines(words: list[OCRWord], *, row_tol: int = 15) -> list[str]:
    """Gabungkan kata menjadi baris berdasarkan posisi ``top``."""
    buckets: dict[int, list[OCRWord]] = {}
    for w in words:
        if not w.text.strip():
            continue
        buckets.setdefault(w.top // row_tol, []).append(w)
    lines: list[str] = []
    for key in sorted(buckets):
        row = sorted(buckets[key], key=lambda x: x.left)
        lines.append(" ".join(x.text for x in row))
    return lines


def _missing_dependency(engine: str, package: str, extra: str) -> "OCREngineError":
    return OCREngineError(
        f"Engine '{engine}' butuh paket '{package}' yang belum terpasang.\n"
        f"Install dengan:  pip install 'fktd[{extra}]'"
    )


class OCREngineError(RuntimeError):
    """Dilempar saat engine tidak tersedia atau gagal dimuat."""


class OCREngine(abc.ABC):
    """Kontrak yang harus dipenuhi tiap backend OCR."""

    name: str = "base"

    @abc.abstractmethod
    def _recognize(self, img_bgr: np.ndarray) -> list[OCRWord]:
        """Kembalikan daftar kata + confidence (0-100) dari gambar BGR."""

    def run(self, image: ImageInput) -> OCRResult:
        img = load_image(image)
        words = self._recognize(img)
        text = "\n".join(reconstruct_lines(words))
        return OCRResult(text=text, words=words, engine=self.name, image=img)
