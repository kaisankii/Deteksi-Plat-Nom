"""Data models for FKTD using pydantic v2."""

from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class FieldConfidence(BaseModel):
    """Nilai sebuah field beserta confidence OCR-nya (0-100)."""

    value: Optional[str] = None
    confidence: float = 0.0


class KTPData(BaseModel):
    """Field hasil ekstraksi dari sebuah KTP.

    Semua field teks bersifat opsional pada level model; *kelengkapan* dan
    *konsistensi* dinilai oleh modul ``fraud``.
    """

    provinsi: Optional[str] = None
    kota_kabupaten: Optional[str] = None
    nik: Optional[str] = None
    nama: Optional[str] = None
    tempat_lahir: Optional[str] = None
    tanggal_lahir: Optional[str] = None  # dd-mm-yyyy
    jenis_kelamin: Optional[str] = None
    golongan_darah: Optional[str] = None
    alamat: Optional[str] = None
    rt_rw: Optional[str] = None
    kel_desa: Optional[str] = None
    kecamatan: Optional[str] = None
    agama: Optional[str] = None
    status_perkawinan: Optional[str] = None
    pekerjaan: Optional[str] = None
    kewarganegaraan: Optional[str] = None
    berlaku_hingga: Optional[str] = None
    tempat_dikeluarkan: Optional[str] = None
    tanggal_dikeluarkan: Optional[str] = None  # dd-mm-yyyy

    # Field boolean dari deteksi gambar.
    has_foto: bool = False
    has_tanda_tangan: bool = False

    # confidence per field (key = nama field), diisi oleh extractor.
    confidences: dict[str, float] = Field(default_factory=dict)

    def confidence_of(self, field: str) -> float:
        return self.confidences.get(field, 0.0)


class Severity(str, Enum):
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


class FraudCheck(BaseModel):
    """Hasil satu aturan pemeriksaan."""

    code: str
    passed: bool
    severity: Severity
    message: str
    weight: int = 0  # kontribusi ke risk score bila gagal


class FraudResult(BaseModel):
    """Ringkasan akhir deteksi fraud."""

    is_passed: bool
    risk_score: int  # 0 (aman) .. 100 (sangat mencurigakan)
    checks: list[FraudCheck]
    data: KTPData

    @property
    def failed_checks(self) -> list[FraudCheck]:
        return [c for c in self.checks if not c.passed]

    def summary(self) -> str:
        status = "PASS" if self.is_passed else "FAIL"
        lines = [f"[{status}] risk_score={self.risk_score}"]
        for c in self.failed_checks:
            lines.append(f"  - ({c.severity.value}) {c.code}: {c.message}")
        return "\n".join(lines)
