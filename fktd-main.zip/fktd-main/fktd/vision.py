"""Deteksi keberadaan FOTO dan TANDA TANGAN dari citra KTP (boolean)."""

from __future__ import annotations

import cv2
import numpy as np

_FACE_CASCADE = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)


def detect_foto(img: np.ndarray) -> bool:
    """Cari wajah di sepertiga kanan kartu (lokasi pas foto KTP)."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
    h, w = gray.shape[:2]
    roi = gray[:, int(w * 0.6) :]  # kolom kanan
    faces = _FACE_CASCADE.detectMultiScale(roi, scaleFactor=1.1, minNeighbors=4)
    return len(faces) > 0


def detect_tanda_tangan(img: np.ndarray) -> bool:
    """Heuristik: area pojok kanan bawah punya goresan gelap (ink strokes)."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
    h, w = gray.shape[:2]
    roi = gray[int(h * 0.7) :, int(w * 0.6) :]  # pojok kanan bawah
    _, binary = cv2.threshold(roi, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    ink_ratio = float(np.count_nonzero(binary)) / binary.size
    # Terlalu kosong = tidak ada ttd; terlalu penuh = bukan ttd (mungkin noise/foto).
    return 0.01 < ink_ratio < 0.45
