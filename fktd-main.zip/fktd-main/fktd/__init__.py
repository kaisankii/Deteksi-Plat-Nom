"""FKTD — Fraud KYC KTP Detector.

OCR multi-engine (EasyOCR / PaddleOCR) + validasi silang ketat untuk KTP Indonesia.
"""

from .detector import FKTD
from .fraud import detect
from .models import FraudCheck, FraudResult, KTPData, Severity
from .nik import NIKInfo, decode_nik

__version__ = "0.1.1"
__all__ = [
    "FKTD",
    "detect",
    "decode_nik",
    "NIKInfo",
    "KTPData",
    "FraudResult",
    "FraudCheck",
    "Severity",
]
