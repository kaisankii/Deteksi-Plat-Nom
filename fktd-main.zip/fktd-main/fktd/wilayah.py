"""Resolver wilayah administratif Indonesia untuk validasi lokasi NIK.

Memetakan kode dari NIK ke nama wilayah:

* 2 digit pertama  -> provinsi
* 4 digit pertama  -> kabupaten/kota

Sumber data:

* **Snapshot bundel** (``fktd/data/``) — selalu tersedia, offline, deterministik.
* **API emsifa** (https://www.emsifa.com/api-wilayah-indonesia/) — dipakai untuk
  menyegarkan / mengisi kode yang belum ada di snapshot.

Mode (``provider``):

* ``"local"`` — snapshot saja (default untuk pemeriksaan offline & test).
* ``"auto"``  — snapshot dulu; bila kode tak ditemukan, query API (fallback aman).
* ``"api"``   — selalu query API live, jatuh ke snapshot bila jaringan gagal.
"""

from __future__ import annotations

import json
import urllib.request
from importlib import resources
from typing import Optional

_API_BASE = "https://www.emsifa.com/api-wilayah-indonesia/api"
_USER_AGENT = "fktd/0.1 (+wilayah-validation)"


def _load_json(filename: str) -> dict:
    with resources.files("fktd.data").joinpath(filename).open(
        "r", encoding="utf-8"
    ) as fh:
        return json.load(fh)


class WilayahResolver:
    """Resolusi nama provinsi & kabupaten/kota dari kode NIK."""

    def __init__(self, *, provider: str = "local", timeout: float = 5.0) -> None:
        if provider not in {"local", "auto", "api"}:
            raise ValueError(f"provider tidak valid: {provider!r}")
        self.provider = provider
        self.timeout = timeout
        self._provinces: dict[str, str] = _load_json("wilayah.json")
        self._regencies: dict[str, str] = _load_json("regencies.json")
        self._api_regency_cache: dict[str, dict[str, str]] = {}

    # -- provinsi -----------------------------------------------------------
    def province_name(self, code2: Optional[str]) -> Optional[str]:
        if not code2 or len(code2) < 2:
            return None
        return self._provinces.get(code2[:2])

    # -- kabupaten/kota -----------------------------------------------------
    def regency_name(self, code4: Optional[str]) -> Optional[str]:
        if not code4 or len(code4) < 4:
            return None
        code4 = code4[:4]

        if self.provider != "api":
            name = self._regencies.get(code4)
            if name or self.provider == "local":
                return name

        # provider "api" atau "auto" (kode tak ada di snapshot) -> coba API.
        api = self._regency_from_api(code4)
        return api or self._regencies.get(code4)

    # -- internal -----------------------------------------------------------
    def _regency_from_api(self, code4: str) -> Optional[str]:
        province_id = code4[:2]
        table = self._api_regency_cache.get(province_id)
        if table is None:
            table = self._fetch_regencies(province_id)
            self._api_regency_cache[province_id] = table
        return table.get(code4)

    def _fetch_regencies(self, province_id: str) -> dict[str, str]:
        url = f"{_API_BASE}/regencies/{province_id}.json"
        try:
            req = urllib.request.Request(url, headers={"User-Agent": _USER_AGENT})
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                rows = json.load(resp)
            return {r["id"]: str(r["name"]).upper() for r in rows}
        except Exception:
            # Jaringan gagal -> diam-diam jatuh ke snapshot.
            return {}
