import re

TO_DIGIT  = {"G": "6", "Z": "2", "O": "0", "I": "1", "B": "8", "S": "5", "Q": "0"}
TO_LETTER = {"6": "G", "2": "Z", "0": "O", "1": "I", "8": "B", "5": "S"}

def fix_plate(raw: str) -> str:
    s = re.sub(r"[^A-Z0-9]", "", raw.upper())
    best, best_cost = raw, 1e9
    for p in (1, 2):                       # panjang kode wilayah
        for d in (1, 2, 3, 4):             # panjang angka
            sfx = len(s) - p - d
            if not 0 <= sfx <= 3:
                continue
            out, cost = [], 0
            for seg, want_digit in zip((s[:p], s[p:p+d], s[p+d:]), (False, True, False)):
                for ch in seg:
                    if ch.isdigit() == want_digit:
                        out.append(ch)
                    else:
                        m = TO_DIGIT if want_digit else TO_LETTER
                        out.append(m.get(ch, ch))
                        cost += 1 if ch in m else 10
                out.append(" ")
            if cost < best_cost:
                best, best_cost = "".join(out).strip(), cost
    return best

print(fix_plate("B G543 ABC"))  # -> B 6543 ABC (kalau segmentasinya kebetulan pas)